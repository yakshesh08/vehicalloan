package com.vechileloanapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VechileloanApplication {

	public static void main(String[] args) {
		SpringApplication.run(VechileloanApplication.class, args);
	}

}
