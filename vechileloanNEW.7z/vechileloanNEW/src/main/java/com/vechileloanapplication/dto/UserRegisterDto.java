package com.vechileloanapplication.dto;

public class UserRegisterDto {
	private String email;
	private String name;
	private String gender;
	private String mobile;
	private int age;

}
