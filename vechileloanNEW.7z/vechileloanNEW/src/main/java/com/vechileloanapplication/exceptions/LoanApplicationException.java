package com.vechileloanapplication.exceptions;



public class LoanApplicationException extends Exception {
    public LoanApplicationException(String message)
    {
        super(message);
    }

 

}