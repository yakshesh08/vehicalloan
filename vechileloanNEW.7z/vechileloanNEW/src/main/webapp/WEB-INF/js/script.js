function name()
          {
          	var adminEmail=document.getElementById("adEm");
          	alter(adminEmail);
          	
          	var password=document.getElementById("pwd");
          	alter(password);
          }
          
          
 
