 function name1()
	
	{
          	var userEmail=document.getElementById("uem");
          	alter(userEmail);
          	
          	var password=document.getElementById("upwd");
          	alter(password);
          }
